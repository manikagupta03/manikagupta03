from datetime import datetime, timedelta
from textwrap import dedent
# The DAG object; we'll need this to instantiate a DAG
from airflow import DAG

# Operators; we need this to operate!
from airflow.operators.bash import BashOperator

# These args will get passed on to each operator
# You can override them on a per-task basis during operator initialization
default_args = {
    'owner': 'airflow',
    'start_date': datetime(2022, 1, 1),
    'depends_on_past': False,
    'email': False,
    'email_on_failure': False,
    'email_on_retries': False,
    'retires': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'Recipe_Insight',
    default_args=default_args,
    schedule_interval="@daily",
    catchup=False
)

task = BashOperator(
    task_id="schedule_run",
    bash_command="sh <path>/run.sh",
    dag=dag
)