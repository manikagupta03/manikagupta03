import isodate
from pyspark.sql.functions import *
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, FloatType

def read_json_data(spark,path):
    return spark.read.json(path)


def iso_dur_cnvrt(cTime):
    if cTime != '':
        duration_min = (isodate.parse_duration(cTime).seconds)/60
    else:
        duration_min = 0
    return duration_min


def duration_calc(df):
    func_udf = udf(iso_dur_cnvrt, FloatType())
    df1 = df.withColumn('cookTime',func_udf(df.cookTime))
    df2 = df1.withColumn('prepTime',func_udf(df.prepTime))
    df2 = df2.persist()
    return df2

def filter_beef(dataframe):
    return dataframe.filter(F.lower(F.col('ingredients')).contains('beef'))

# df_filtered = filter_beef(df2)

def difficulty_level(cookTime, prepTime):
    if cookTime == '' or prepTime == '':
        return "Unkown"

    total_cook_time = cookTime + prepTime
    if total_cook_time >= 60.0:
        return "Hard"
    elif total_cook_time >= 30.0 and total_cook_time < 60.0:
        return "Medium"
    elif total_cook_time < 30.0:
        return "Easy"
    else:
        return "Unkown"


def data_final(df_filtered):
    func_udf = udf(difficulty_level, StringType())
    df_filtered = df_filtered.withColumn("difficulty", func_udf(df_filtered.cookTime, df_filtered.prepTime))
    df_filtered = df_filtered.withColumn("total_cook_time", df_filtered.cookTime+df_filtered.prepTime)
    df_final = df_filtered.groupBy("difficulty").avg('total_cook_time').select("difficulty",round(F.col("avg(total_cook_time)"),2).alias("avg_total_cooking_time"))
    return df_final

def save_df(df_final):
    df_final.coalesce(1).write.format("csv").option("header",True).mode("overwrite").save("..\\output\\")