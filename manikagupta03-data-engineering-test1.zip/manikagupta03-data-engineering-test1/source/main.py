from pyspark.sql import SparkSession
from source.difficulty_calc_recepies import *

def main():
    spark = SparkSession.builder.appName("hello_test").getOrCreate()
    df = read_json_data(spark,"..\\input\\*.json")
    df2 = duration_calc(df)
    df_filtered = filter_beef(df2)
    df_final = data_final(df_filtered)
    save_df(df_final)

if __name__ == "__main__":
    main()