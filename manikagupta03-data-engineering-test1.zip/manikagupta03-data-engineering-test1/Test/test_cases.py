from pyspark.sql import SparkSession
from source.difficulty_calc_recepies import *


spark = SparkSession.builder.appName("hello_test1").getOrCreate()
input_path = "C:\\Users\\manikgupta\\PycharmProjects\\manikagupta03-data-engineering-test\\Test\\sample_data.json"

# Test Case 1
df_code = read_json_data(spark,input_path)
df_test = spark.read.json(input_path)

assert (df_test.count()) == (df_code.count()),'Count not matching'
print('Test case 1 Passed')

# Test Case 2
df_code = duration_calc(df_code.filter(df_code.cookTime=='PT6H'))
df_code1 = df_code.select('cookTime')
assert (df_code1.collect()[0]['cookTime']) == 360.0, 'Not correctly converted'
print('Test Case 2 Passed')

# Test Case 3
df_code = read_json_data(spark,input_path)
df_code_filtered = filter_beef(df_code)
assert(df_code_filtered.count()) == 6, 'Not filtered correctly'
print('Test Case 3 Passed')
