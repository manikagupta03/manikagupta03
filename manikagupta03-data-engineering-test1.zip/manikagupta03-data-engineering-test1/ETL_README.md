Approach:
1. This code reads json files containing recepies in a spark dataframe.
2. Then it preprocesses the data where it majorly interprets two duration columns cookTime and prepTime in float minutes from ISOFormat and persists that df.
3. Then it filters the recepies consisting 'beef' as one of the ingredients
4. Then on filtered dataframe it calculates the total cooking duration of every recepie and then checks the difficulty level.
5. Finally it calculates the avg_total_cooking_time based on difficulty level and save the resulted dataframe as a csv file on output folder.
6. There are a couple of ways to schedule main.py
    a. Using CronTab
    b. Using Airflow: created a sample DAG in scheduler.py file which uses BashOperator to execute run.sh containing spark-submit job on daily basis.
7. cicd.yml file will setup the environment and install the required dependencies and execute test cases.

Assumptions:
1. Input file should exist
2. Input file should not be blank
3. Input file should be in json format
4. cookTime should not be blank and datePublished should not be NULL
5. There are records available with beef as one of the ingredients
6. prepTime and cookTime must be in correct duration ISO Format

Instructions:
(Cluster Execution)
1. Either zip entire code along with required dependencies or install the dependencies
2. Use shell script run.sh to execute main.py which contains a spark-submit command
   example: sh run.sh

(Local Execution)
1. Clone the git repository
2. Install required dependencies like pyspark,py4j
3. Execute main.py