from pyspark.sql import SparkSession
import pyspark.sql.functions as F

spark = SparkSession.builder.appName("hello_test").getOrCreate()
input_path = "C:\\Users\\manikgupta\\PycharmProjects\\manikagupta03-data-engineering-test\\input\\*.json"

def check_file_not_blank(input_path):
    df = spark.read.json(input_path)
    if df.count() == 0:
        print('File is blank which is not expected!')
    return

def file_exists(input_path):
    try:
        df = spark.read.json(input_path)
    except:
        print('ERROR! File does not exist')
    return

def filtered_df(input_path):
    df = spark.read.json(input_path)
    df_filtered = df.filter(F.lower(F.col('ingredients')).contains('beef'))
    if df_filtered.count() == 0:
        print('Data does not have any entry with beef as one of the ingredients')
    return

def datePublished_null(input_path):
    df = spark.read.json(input_path)
    if len(df.where(F.col('datePublished').isNull()).limit(1).collect())==1:
        print('datePublished cannot be NULL!')
    return

def cookTime_empty(input_path):
    df = spark.read.json(input_path)
    if len(df.where(F.col('cookTime')=='').limit(1).collect())==1:
        print('cookTime cannot be empty!')
    return